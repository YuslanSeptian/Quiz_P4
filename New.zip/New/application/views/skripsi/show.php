<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuizP4 List Data</title>
</head>
<body>
    <table border="1" align="center">
        <tr>
            <td>Nim</td>
            <td>Nama</td>
            <td>Judul</td>
            <td>Pembimbim</td>
            <td>Action</td>
        </tr>
        <?php foreach($tskripsi as $s):  ?>
        <tr>
            <td><?=$s->nim ?></td>
            <td><?=$s->nama ?></td>
            <td><?=$s->judul ?></td>
            <td><?=$s->pemb ?></td>
            <td><a href="<?= site_url('skripsi/edit/'.$s->nim_id)?>">Edit</a>||<a href="<?= site_url('skripsi/delete/'.$s->nim_id)?>">Hapus</a></td>            
        </tr>
            <?php endforeach ?>
    </table>
<center>
    <a href="<?=site_url('skripsi')?>">Kembali</a>||<a href="<?=site_url('skripsi/create')?>">Tambah Data</a>
</center>

</body>
</html>