<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuizP4 Home</title>
</head>
<body>

<table align="center">
    <tr>
        <td><h1><a href="<?=site_url('skripsi/create')?>">Insert Data</a></h1></td>
    </tr>
    <tr>
        <td><h1><a href="<?=site_url('skripsi/show')?>">Tampil Data</a></h1></td>
    </tr>
</table>
</body>
</html>