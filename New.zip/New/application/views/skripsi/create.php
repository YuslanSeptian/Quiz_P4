<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuizP4 Insert Data</title>
</head>
<body>
    <center>
        <h1> Insert Data </h1>
        <table style="margin:20px auto;">
        <form action="<?=site_url('/skripsi/add') ?>" method="post">
			<tr>
				<td>Nim</td>
				<td><input type="text" name="nim"></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr>
				<td>Judul</td>
				<td><input type="text" name="judul"></td>
			</tr>
			<tr>
				<td>Pembimbim</td>
				<td><input type="text" name="pemb"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" value="Tambah"></td>
			</tr>
        </table>
</form>
    <a href="<?=site_url('skripsi')?>">Kembali</a>||<a href="<?=site_url('skripsi/show')?>">Lihat Data</a>
</center>
</body>
</html>