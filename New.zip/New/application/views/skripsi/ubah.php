<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Edit</title>
</head>
<body>
    <center>
        <h1> Edit Data </h1>
        <form action="" method="post">
            <input type="hidden" name="nim_id" value="<?php echo $tskripsi->nim_id;?>">
            <div>
                <label for="">Nim</label>
                <input type="text" name="nim" value="<?php echo $tskripsi->nim;?>">
            </div>
            <div>
                <label for="">Nama</label>
                <input type="text" name="nama" value="<?php echo $tskripsi->nama;?>" >
            </div>
            <div>
                <label for="">Judul</label>
                <input type="text" name="judul" value="<?php echo $tskripsi->judul;?>">
            </div>
            <div>
                <label for="">Pembimbing</label>
                <input type="text" name="pemb" value="<?php echo $tskripsi->pemb;?>">
            </div>
			<input type="submit" value="Update">
        </form>
    <a href="<?=site_url('skripsi')?>">Kembali</a>||<a href="<?=site_url('skripsi/show')?>">Lihat Data</a>
</center>
</body>
</html>