<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Skripsi extends CI_Controller{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('Quiz_model');
        $this->load->library('form_validation');
    }

    public function index(){
        $this->load->view('skripsi/home');
    }
    
    public function show(){
        $data["tskripsi"] = $this->Quiz_model->getAll();
        $this->load->view('skripsi/show',$data);
    }

    public function create(){
        $this->load->view('skripsi/create');
    }

    public function add(){
        $tskripsi = $this->Quiz_model;
        $validation = $this->form_validation;
        $validation->set_rules($tskripsi->rules());

        if($validation->run()){
            $tskripsi->save();
            $this->session->set_flashdata('success','Berhasil');
        }
        // $this->load->view("skripsi/show");
        redirect(site_url('skripsi/show'));
    }

    public function edit($id=null){
        if(!isset($id)) redirect('skripsi/create');

        $tskripsi = $this->Quiz_model;
        $validation = $this->form_validation;
        $validation->set_rules($tskripsi->rules());

        if($validation->run()){
            $tskripsi->update();
            redirect(site_url('skripsi/show'));
            $this->session->set_flashdata('success',"Berhasil");
        }
        $data["tskripsi"] = $tskripsi->getById($id);
        if(!$data["tskripsi"]) show_404();

        $this->load->view("skripsi/ubah",$data);
    }

    public function delete($id=null){
        if(!isset($id))show_404();
        if($this->Quiz_model->delete($id)){
            redirect(site_url('skripsi/show'));
        }
    }

}


?>