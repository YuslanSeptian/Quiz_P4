<?php 

class Quiz_model extends CI_Model{

    private $_table = "tskripsi";

    public $nim_id;
    public $nim;
    public $nama;
    public $judul;
    public $pemb;

    public function rules()
        {
        return[
            ['field'   => 'nim',
            'label'    => 'Nim',
            'rules'    => 'required'],

            ['field'   => 'nim',
            'label'    => 'Nim',
            'rules'    => 'required'],
        ];
    }

    public function getAll(){
        return $this->db->get($this->_table)->result();
    }

    public function getById($id){
        return $this->db->get_where($this->_table,["nim_id"=>$id])->row();
    }

    public function save(){
        $post = $this->input->post();
        // $this->nim_id   = uniqid();
        $this->nim      = $post["nim"];
        $this->nama     = $post["nama"];
        $this->judul    = $post["judul"];
        $this->pemb     = $post["pemb"];
        return $this->db->insert($this->_table,$this);
    }
    
    public function update(){
        $post = $this->input->post();
        $this->nim_id   = $post["nim_id"];
        $this->nim      = $post["nim"];
        $this->nama     = $post["nama"];
        $this->judul    = $post["judul"];
        $this->pemb     = $post["pemb"];
        return $this->db->update($this->_table,$this,array('nim_id'=>$post['nim_id']));
    }

    public function delete($id){
        return $this->db->delete($this->_table,array("nim_id" => $id));
    }

}

?>